student_data <- read.csv('Student_Data_6.csv', stringsAsFactors = T)
str(student_data)

### Dependent Variable = 'card'

student_data$card = student_data$card == 1

### Create training and test dataset
set.seed(1)
isTraining = runif(nrow(student_data))<.8
trainingData = subset(student_data,isTraining)
validationData = subset(student_data,!isTraining)

### Create Correlation Plot
library(corrplot)
corrplot(cor(model.matrix(~.,data=student_data)))

### Some obvious correlations are - negative correlation between reports and cardTrue as well as positive correlation between expenditure and cardTrue

summary(lm(card~., data=student_data))

anova(lm(card~., data=student_data))

library('leaps')

basicSubset = regsubsets(card~.,data=student_data)
basicSummary = summary(basicSubset)
bestAIC = which.min(basicSummary$cp)
bestBIC = which.min(basicSummary$bic)


coef(basicSubset,bestBIC)


library(earth)
earth1 = earth(card~.,data=trainingData)
plotmo(earth1)
