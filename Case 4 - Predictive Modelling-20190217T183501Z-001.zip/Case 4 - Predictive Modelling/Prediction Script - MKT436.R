
############################################
#detailData
############################################
#Load the detailing data 
setwd('C:/Users/Avery/Dropbox/MKT436(R) Materials/Cases')
library('earth')
set.seed(1343)
detailData = read.csv('Detailing Case Data.csv')

#Generate a training set that is 80% of the data, and a validation set that is 20% 
isTraining = runif(nrow(detailData))<.8  
detailTrain = subset(detailData,isTraining)
detailValid = subset(detailData,!isTraining)

#Function returns the RMSE using the validation set for the detailing data
getDetailRMSE = function(model){
  actualY = detailValid$scripts
  predictedY = predict(model,detailValid)
	return(mean((actualY-predictedY)^2)^.5)
}

#Check the performance of various predictive methods, with some predictive tuning.
#Linear Regression 
getDetailRMSE(lm(scripts~.,data=detailTrain))
getDetailRMSE(lm(scripts~.^2,data=detailTrain))


#Mars Model 
getDetailRMSE(earth(scripts~.,data=detailTrain))
getDetailRMSE(earth(scripts~.,degree=2,data=detailTrain))
getDetailRMSE(earth(scripts~.,degree=2,thres=.1,data=detailTrain))
getDetailRMSE(earth(scripts~.,degree=2,thres=.001,data=detailTrain))
getDetailRMSE(earth(scripts~.,degree=2,pmethod='cv',nfold=5,ncross=3,data=detailTrain,varmod.method='lm'))

#Use what we learned in the descriptive analysis to suggest the correct terms 
getDetailRMSE(earth(scripts~mean_samples*lagged_scripts+detailing*lagged_scripts+lagged_scripts*factor(doctorType),data=detailTrain))

getDetailRMSE(lm(scripts~mean_samples*lagged_scripts+detailing*lagged_scripts+lagged_scripts*factor(doctorType),data=detailTrain))

#Random Forest
install.packages('randomForest')
library('randomForest')
getDetailRMSE(randomForest(scripts~.,data=detailTrain))
getDetailRMSE(randomForest(scripts~.^2,data=detailTrain))

library('nnet')
getDetailRMSE(nnet(scripts~.,data=detailTrain,linout=1,size=10,maxit=100000))


#Re-estimate best model on the full data 
finalDetailModel = earth(scripts~mean_samples*lagged_scripts+detailing*lagged_scripts+lagged_scripts*factor(doctorType),data=detailData)

############################################
#HDMA Data 
############################################
#Do a similar exercise on Mortgage data 
#We won't look deeply at this dataset because we don't have too in a predictive analysis 
#Load the data 
install.packages('AER')
library('AER')
data("HMDA")
HMDA$deny = as.numeric(HMDA$deny)


#Set up training and validation sets 
isTraining = runif(nrow(HMDA))<.8    

hdmaTrain = subset(HMDA,isTraining)
hdmaValid = subset(HMDA,!isTraining)

#Function returns the RMSE using the validation set for the HMDA data
getHDMARMSE = function(model){
	return(mean((hdmaValid$deny-predict(model,hdmaValid))^2)^.5)
}

#Linear Regression 
getHDMARMSE(lm(deny~.,data=hdmaTrain))
getHDMARMSE(lm(deny~.^2,data=hdmaTrain))

#Mars Model 
getHDMARMSE(earth(deny~.,data=hdmaTrain))
getHDMARMSE(earth(deny~.,degree=2,data=hdmaTrain))
getHDMARMSE(earth(deny~.,degree=2,data=hdmaTrain))
getHDMARMSE(earth(deny~.,degree=3,thres=.001,data=hdmaTrain))
getHDMARMSE(earth(deny~.,degree=2,thres=.0001,data=hdmaTrain))
getHDMARMSE(earth(deny~.,degree=2,thres=.01,data=hdmaTrain))


getHDMARMSE(earth(deny~.,data=hdmaTrain,thres=.01))

#Learn More 
plotmo(earth(deny~.,data=hdmaTrain,thres=.01,degree=2))

#Force in interactions
getHDMARMSE(earth(deny~.+chist*pirat+pirat*mhist,data=hdmaTrain,thres=.01))
getHDMARMSE(earth(deny~.+chist*pirat+pirat*mhist,data=hdmaTrain))
getHDMARMSE(earth(deny~.+chist*pirat+pirat*mhist,data=hdmaTrain,thres=.2))

#Random Forest
install.packages('randomForest')
library('randomForest')
getHDMARMSE(randomForest(deny~.,data=hdmaTrain))
getHDMARMSE(randomForest(deny~.^2,data=hdmaTrain))
getHDMARMSE(randomForest(deny~.^2,data=hdmaTrain,mtry=4))

getHDMARMSE(randomForest(deny~.^2,data=hdmaTrain,mtry=2))
getHDMARMSE(randomForest(deny~.^2,data=hdmaTrain,mtry=3))

#Now that we know the best model type, re estimate with full data 
finalHDMAModel = randomForest(deny~.,data=HMDA)

##########################################################
##########################################################
#MKT436R Only - detailData - with k-fold cross validation 
##########################################################
##########################################################
#Detailing data with k-fold cross valiation 
set.seed(1343)
detailData = read.csv('Detailing Case Data.csv')

set.seed(1) 
nFold = 10
#Step 1: Randomly choose which fold each row is in 
valNum = floor(runif(nrow(detailData))*nFold)+1

#Function returns k-fold cross validation error 
getDetailRMSE = function(modelCall){
	modelPerformance = rep(NA,nFold)
	for(fold in 1:nFold){
		#Step 2i: Get the training and validation data for this fold
		trainingData = subset(detailData,valNum!=fold)
		validationData = subset(detailData,valNum==fold)
		
		#Step 2ii: Estimate the model for this training data
		model = update(modelCall,data=trainingData)
		#Step 2iii: Calculate out of sample MSE for this validationData
		validRMSE =  mean((validationData$scripts - predict(model,validationData))^2)^.5
		#Store model performance		
		modelPerformance[fold] = validRMSE
	}
	return(mean(modelPerformance))
}

#Remainder of the code is similar 

#Linear Regression 
getDetailRMSE(lm(scripts~.,data=detailTrain))
getDetailRMSE(lm(scripts~.^2,data=detailTrain))

#Mars Model 
getDetailRMSE(earth(scripts~.,data=detailTrain))
getDetailRMSE(earth(scripts~.,degree=2,data=detailTrain))
getDetailRMSE(earth(scripts~.,degree=2,thres=.1,data=detailTrain))
getDetailRMSE(earth(scripts~.,degree=2,thres=.001,data=detailTrain))


#Use what we learned in the descriptive analysis to suggest the correct terms 
getDetailRMSE(earth(scripts~mean_samples*lagged_scripts+detailing*lagged_scripts+lagged_scripts*factor(doctorType),data=detailTrain))

#Random Forest
install.packages('randomForest')
library('randomForest')
#This will take a while 
getDetailRMSE(randomForest(scripts~.,data=detailTrain))

#Re-estimate best model on the full data 
finalDetailModel = lm(deny~.^2,data=detailData)



############################################
#HDMA Data 
############################################
install.packages('AER')
library('AER')
data("HMDA")
HMDA$deny = as.numeric(HMDA$deny)

set.seed(1) 
nFold = 10
#Step 1: Randomly choose which fold each row is in 
valNum = floor(runif(nrow(HMDA))*nFold)+1

getDetailRMSE = function(modelCall){
	modelPerformance = rep(NA,nFold)
	for(fold in 1:nFold){
		#Step 2i: Get the training and validation data for this fold
		trainingData = subset(HMDA,valNum!=fold)
		validationData = subset(HMDA,valNum==fold)
		
		#Step 2ii: Estimate the models for this training data
		model = update(modelCall,data=trainingData)
		#Step 2iii: Calculate out of sample MSE for this validationData
		validRMSE =  mean((validationData$deny - predict(model,validationData))^2)^.5
		#Store model performance		
		modelPerformance[fold] = validRMSE
		
	}
	return(mean(modelPerformance))
}



#Remainder of the code is similar 
#Linear Regression 
getHDMARMSE(lm(deny~.,data=hdmaTrain))
getHDMARMSE(lm(deny~.^2,data=hdmaTrain))

#Mars Model 
getHDMARMSE(earth(deny~.,data=hdmaTrain))
getHDMARMSE(earth(deny~.,degree=2,data=hdmaTrain))
getHDMARMSE(earth(deny~.,degree=2,data=hdmaTrain))
getHDMARMSE(earth(deny~.,degree=3,thres=.001,data=hdmaTrain))
getHDMARMSE(earth(deny~.,degree=2,thres=.0001,data=hdmaTrain))
getHDMARMSE(earth(deny~.,degree=2,thres=.01,data=hdmaTrain))


getHDMARMSE(earth(deny~.,data=hdmaTrain,thres=.01))

#Learn More 
plotmo(earth(deny~.,data=hdmaTrain,thres=.01,degree=2))

#Force in interactions
getHDMARMSE(earth(deny~.+chist*pirat+pirat*mhist,data=hdmaTrain,thres=.01))
getHDMARMSE(earth(deny~.+chist*pirat+pirat*mhist,data=hdmaTrain))
getHDMARMSE(earth(deny~.+chist*pirat+pirat*mhist,data=hdmaTrain,thres=.2))

#Random Forest
install.packages('randomForest')
library('randomForest')
getHDMARMSE(randomForest(deny~.,data=hdmaTrain))

finalHDMAModel = randomForest(deny~.,data=HMDA)

